package com.basar.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BasarService extends Service {
    private static final String REPLY =
        "এখানে, আমি এখানে। আমাকে আপনি খুঁজতেছেন? খুঁজে দেওয়ার জন্য ধন্যবাদ, খাদিমুল বাশার।";

    private static final class Phrase {
        final List<float[][]> takes = new ArrayList<>();
        double limit;
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Phrase> phrases = new ArrayList<>();
    private final Runnable unmute = () -> speaking = false;
    private volatile boolean running, speaking;
    private Thread listener;
    private PowerManager.WakeLock wakeLock;
    private TextToSpeech tts;
    private ImageView bubble;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_STICKY;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("basar", "BASAR", NotificationManager.IMPORTANCE_LOW));
        Notification note = new Notification.Builder(this, "basar")
            .setContentTitle("BASAR শুনছে")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE))
            .setOngoing(true)
            .build();
        try {
            startForeground(1, note);
        } catch (RuntimeException e) {
            // Android may refuse a microphone service restarted from the background.
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Samples.complete(this) || !loadSamples()) {
            Toast.makeText(this, "আগে ডাক রেকর্ড করুন", Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }
        running = true;
        wakeLock = getSystemService(PowerManager.class)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "basar:listen");
        wakeLock.acquire();
        startVoice();
        showBubble();
        listener = new Thread(this::listen, "basar-listen");
        listener.start();
        return START_STICKY;
    }

    private boolean loadSamples() {
        phrases.clear();
        try {
            for (int p = 0; p < Samples.PHRASES.length; p++) {
                Phrase phrase = new Phrase();
                for (int t = 0; t < Samples.TIMES; t++)
                    phrase.takes.add(Wake.features(Samples.load(Samples.file(this, p, t))));
                double worst = 0;
                for (int a = 0; a < Samples.TIMES; a++)
                    for (int b = a + 1; b < Samples.TIMES; b++) {
                        double d = Wake.distance(phrase.takes.get(a), phrase.takes.get(b));
                        if (d < Double.MAX_VALUE) worst = Math.max(worst, d);
                    }
                // Limit comes from how much the speaker's own takes differ, kept in a safe range.
                phrase.limit = Math.min(3.0, Math.max(1.8, worst * 1.1));
                phrases.add(phrase);
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private void listen() {
        Wake.Segmenter segmenter = new Wake.Segmenter();
        short[] chunk = new short[Wake.CHUNK];
        AudioRecord mic = null;
        int filled = 0;
        while (running) {
            if (mic == null) {
                mic = Samples.openMic();
                if (mic == null) {
                    pause();
                    continue;
                }
            }
            int n = mic.read(chunk, filled, chunk.length - filled);
            if (n <= 0) {
                mic.release();
                mic = null;
                filled = 0;
                pause();
                continue;
            }
            filled += n;
            if (filled < chunk.length) continue;
            filled = 0;
            if (speaking) {
                segmenter.reset();
                continue;
            }
            short[] said = segmenter.feed(chunk);
            if (said != null && matches(Wake.features(said))) {
                speaking = true;
                handler.post(this::answer);
            }
        }
        if (mic != null) mic.release();
    }

    private void pause() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            running = false;
        }
    }

    private boolean matches(float[][] said) {
        SharedPreferences prefs = getSharedPreferences("basar", MODE_PRIVATE);
        double scale = 0.7 + prefs.getInt("sense", 30) / 100.0;
        for (Phrase p : phrases) {
            double best = Double.MAX_VALUE;
            for (float[][] take : p.takes) best = Math.min(best, Wake.distance(said, take));
            if (best <= p.limit * scale) return true;
        }
        return false;
    }

    private void startVoice() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            tts.setLanguage(new Locale("bn", "BD"));
            tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM).build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                public void onStart(String id) {}
                public void onDone(String id) { handler.postDelayed(unmute, 700); }
                public void onError(String id) { handler.post(unmute); }
            });
        });
    }

    private void answer() {
        speaking = true;
        handler.removeCallbacks(unmute);
        AudioManager am = getSystemService(AudioManager.class);
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        int result = tts.speak(REPLY, TextToSpeech.QUEUE_FLUSH, null, "r");
        // Safety net in case the voice engine never reports that it finished.
        handler.postDelayed(unmute, result == TextToSpeech.SUCCESS ? 15000 : 500);
    }

    private void showBubble() {
        WindowManager wm = getSystemService(WindowManager.class);
        SharedPreferences prefs = getSharedPreferences("basar", MODE_PRIVATE);
        int size = Math.round(52 * getResources().getDisplayMetrics().density);
        bubble = new ImageView(this);
        bubble.setImageResource(R.drawable.icon);
        bubble.setOnClickListener(v -> answer());
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = prefs.getInt("x", 0);
        lp.y = prefs.getInt("y", getResources().getDisplayMetrics().heightPixels / 3);
        int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true;
                        if (moved) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) v.performClick();
                        else prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply();
                        return true;
                    default:
                        return false;
                }
            }
        });
        wm.addView(bubble, lp);
    }

    @Override
    public void onDestroy() {
        running = false;
        if (listener != null) listener.interrupt();
        handler.removeCallbacksAndMessages(null);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (tts != null) tts.shutdown();
        if (bubble != null) getSystemService(WindowManager.class).removeView(bubble);
        super.onDestroy();
    }
}
