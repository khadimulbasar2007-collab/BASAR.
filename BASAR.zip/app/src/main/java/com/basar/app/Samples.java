package com.basar.app;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

final class Samples {
    static final String[] PHRASES = {"হে মোবাইল", "হে বাশার", "মোবাইল তুমি কোথায়"};
    static final int TIMES = 3;

    static File file(Context c, int phrase, int take) {
        return new File(c.getFilesDir(), "t" + phrase + "_" + take + ".pcm");
    }

    static boolean complete(Context c) {
        for (int p = 0; p < PHRASES.length; p++)
            for (int t = 0; t < TIMES; t++)
                if (!file(c, p, t).exists()) return false;
        return true;
    }

    static void save(File f, short[] pcm) throws IOException {
        try (DataOutputStream out = new DataOutputStream(new FileOutputStream(f))) {
            for (short s : pcm) out.writeShort(s);
        }
    }

    static short[] load(File f) throws IOException {
        short[] pcm = new short[(int) (f.length() / 2)];
        try (DataInputStream in = new DataInputStream(new FileInputStream(f))) {
            for (int i = 0; i < pcm.length; i++) pcm[i] = in.readShort();
        }
        return pcm;
    }

    /** Needs RECORD_AUDIO. Returns null if the microphone cannot be opened. */
    static AudioRecord openMic() {
        int min = AudioRecord.getMinBufferSize(Wake.RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        try {
            AudioRecord r = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, Wake.RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, Wake.RATE * 2));
            if (r.getState() == AudioRecord.STATE_INITIALIZED) {
                r.startRecording();
                return r;
            }
            r.release();
        } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
            return null;
        }
        return null;
    }
}
