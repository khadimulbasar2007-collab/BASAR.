package com.basar.app;

import android.Manifest;
import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.widget.ImageView;
import android.content.ActivityNotFoundException;
import android.media.AudioRecord;
import android.os.PowerManager;
import android.os.SystemClock;
import android.widget.SeekBar;
import java.io.IOException;
import android.speech.tts.TextToSpeech;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(48, 48, 48, 48);

        box.setBackgroundColor(0xFF05070F);

        ImageView photo = new ImageView(this);
        photo.setImageResource(R.drawable.photo);
        photo.setAdjustViewBounds(true);
        box.addView(photo, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView title = new TextView(this);
        title.setText("BASAR");
        title.setTextSize(40);
        title.setTextColor(0xFF1E9BFF);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setText(Samples.complete(this) ? "চালু করুন চাপুন" : "প্রথমে ডাক রেকর্ড করুন");
        box.addView(status);

        Button rec = new Button(this);
        rec.setText("ডাক রেকর্ড করুন");
        rec.setOnClickListener(v -> record());
        style(rec);
        box.addView(rec);

        Button start = new Button(this);
        start.setText("চালু করুন");
        start.setOnClickListener(v -> begin());
        style(start);
        box.addView(start);

        Button stop = new Button(this);
        stop.setText("বন্ধ করুন");
        stop.setOnClickListener(v -> stopService(new Intent(this, BasarService.class)));
        style(stop);
        box.addView(stop);
        Button offline = new Button(this);
        offline.setText("বাংলা ভয়েস নামান");
        offline.setOnClickListener(v -> setupOffline());
        style(offline);
        box.addView(offline);
        TextView label = new TextView(this);
        label.setText("সংবেদনশীলতা (সাড়া না দিলে ডানে টানুন)");
        label.setTextColor(0xFFFFFFFF);
        label.setGravity(Gravity.CENTER);
        box.addView(label);

        SeekBar sense = new SeekBar(this);
        sense.setMax(70);
        sense.setProgress(getSharedPreferences("basar", MODE_PRIVATE).getInt("sense", 30));
        sense.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                getSharedPreferences("basar", MODE_PRIVATE).edit().putInt("sense", value).apply();
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });
        box.addView(sense, new LinearLayout.LayoutParams(-1, -2));
        setContentView(box);
    }

    private void style(Button b) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF0B1B3A);
        bg.setStroke(4, 0xFF1E9BFF);
        bg.setCornerRadius(60);
        b.setBackground(bg);
        b.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 24;
        b.setLayoutParams(p);
    }

    private volatile boolean recording;
    private TextView status;

    private void setupOffline() {
        try {
            startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "ফোনের Text-to-speech সেটিংস থেকে বাংলা নামান", Toast.LENGTH_LONG).show();
        }
    }

    private boolean micAllowed() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) return true;
        String[] p = Build.VERSION.SDK_INT >= 33
            ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
            : new String[]{Manifest.permission.RECORD_AUDIO};
        requestPermissions(p, 1);
        Toast.makeText(this, "অনুমতি দিয়ে আবার চাপুন", Toast.LENGTH_LONG).show();
        return false;
    }

    private void record() {
        if (recording || !micAllowed()) return;
        stopService(new Intent(this, BasarService.class));
        recording = true;
        new Thread(() -> {
            boolean ok = true;
            for (int p = 0; p < Samples.PHRASES.length && ok; p++) {
                for (int t = 0; t < Samples.TIMES && ok; t++) {
                    show("একটু অপেক্ষা করুন...");
                    SystemClock.sleep(1200);
                    ok = recordOne(p, t);
                }
            }
            show(ok ? "রেকর্ড শেষ। এবার চালু করুন চাপুন" : "রেকর্ড হয়নি। আবার চেষ্টা করুন");
            recording = false;
        }).start();
    }

    private boolean recordOne(int p, int t) {
        AudioRecord mic = Samples.openMic();
        if (mic == null) return false;
        try {
            Wake.Segmenter segmenter = new Wake.Segmenter();
            short[] chunk = new short[Wake.CHUNK];
            show("বলুন: " + Samples.PHRASES[p] + " (" + (t + 1) + "/" + Samples.TIMES + ")");
            long end = SystemClock.elapsedRealtime() + 10000;
            while (recording && SystemClock.elapsedRealtime() < end) {
                if (mic.read(chunk, 0, chunk.length, AudioRecord.READ_BLOCKING) != chunk.length) return false;
                short[] said = segmenter.feed(chunk);
                if (said != null) {
                    Samples.save(Samples.file(this, p, t), said);
                    return true;
                }
            }
            return false;
        } catch (IOException e) {
            return false;
        } finally {
            mic.release();
        }
    }

    private void show(String text) {
        runOnUiThread(() -> status.setText(text));
    }

    @Override
    protected void onDestroy() {
        recording = false;
        super.onDestroy();
    }

    private void begin() {
        if (recording || !micAllowed()) return;
        if (!Samples.complete(this)) {
            Toast.makeText(this, "আগে ডাক রেকর্ড করুন", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
            return;
        }
        if (!getSystemService(PowerManager.class).isIgnoringBatteryOptimizations(getPackageName())) {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:" + getPackageName())));
            return;
        }
        startForegroundService(new Intent(this, BasarService.class));
    }
}
