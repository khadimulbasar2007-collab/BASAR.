package com.basar.app;

import java.util.ArrayDeque;

/** Offline wake phrase matching: voice activity detection, MFCC and DTW. */
final class Wake {
    static final int RATE = 16000;
    static final int CHUNK = 320;

    static final class Segmenter {
        private final ArrayDeque<short[]> pre = new ArrayDeque<>();
        private final short[] buf = new short[RATE * 3];
        private double floor = 200;
        private int length, quiet, loud;
        private boolean active, overflow;

        void reset() {
            pre.clear();
            length = quiet = loud = 0;
            active = overflow = false;
        }

        /** Feed 20 ms of audio. Returns a finished utterance, or null. */
        short[] feed(short[] chunk) {
            double sum = 0;
            for (short s : chunk) sum += (double) s * s;
            double rms = Math.sqrt(sum / chunk.length);
            boolean voice = rms > Math.max(floor * 3, 350);
            if (!active) {
                pre.add(chunk.clone());
                if (pre.size() > 10) pre.remove();
                if (voice) {
                    loud++;
                } else {
                    loud = 0;
                    floor = floor * 0.95 + rms * 0.05;
                }
                if (loud >= 3) {
                    active = true;
                    for (short[] p : pre) add(p);
                    pre.clear();
                }
                return null;
            }
            add(chunk);
            quiet = voice ? 0 : quiet + 1;
            // A steady loud noise slowly raises the floor so that it ends the segment.
            floor = floor * 0.998 + rms * 0.002;
            if (quiet < 20) return null;
            short[] out = null;
            int speech = length - quiet * CHUNK;
            if (!overflow && speech >= RATE * 3 / 10) {
                out = new short[Math.min(length, speech + 5 * CHUNK)];
                System.arraycopy(buf, 0, out, 0, out.length);
            }
            reset();
            return out;
        }

        private void add(short[] c) {
            if (length + c.length > buf.length) {
                overflow = true;
                return;
            }
            System.arraycopy(c, 0, buf, length, c.length);
            length += c.length;
        }
    }

    static float[][] features(short[] pcm) {
        final int size = 400, hop = 160, n = 512, bands = 26, coeffs = 12;
        int frames = Math.max(0, (pcm.length - size) / hop + 1);
        float[][] out = new float[frames][coeffs];
        int[] edge = new int[bands + 2];
        double top = mel(7600), bottom = mel(100);
        for (int i = 0; i < edge.length; i++) {
            double m = bottom + (top - bottom) * i / (bands + 1);
            double hz = 700 * (Math.pow(10, m / 2595) - 1);
            edge[i] = (int) Math.floor((n + 1) * hz / RATE);
        }
        for (int f = 0; f < frames; f++) {
            double[] re = new double[n], im = new double[n];
            for (int i = 0; i < size; i++) {
                int p = f * hop + i;
                double x = pcm[p] - (p > 0 ? 0.97 * pcm[p - 1] : 0);
                re[i] = x * (0.54 - 0.46 * Math.cos(2 * Math.PI * i / (size - 1)));
            }
            fft(re, im);
            double[] energy = new double[bands];
            for (int b = 0; b < bands; b++) {
                double e = 0;
                for (int k = edge[b]; k < edge[b + 2]; k++) {
                    double w = k < edge[b + 1]
                        ? (double) (k - edge[b]) / (edge[b + 1] - edge[b])
                        : (double) (edge[b + 2] - k) / (edge[b + 2] - edge[b + 1]);
                    e += w * (re[k] * re[k] + im[k] * im[k]);
                }
                energy[b] = Math.log(e + 1);
            }
            for (int c = 0; c < coeffs; c++) {
                double v = 0;
                for (int b = 0; b < bands; b++) v += energy[b] * Math.cos(Math.PI * (c + 1) * (b + 0.5) / bands);
                out[f][c] = (float) v;
            }
        }
        for (int c = 0; c < coeffs && frames > 0; c++) {
            double mean = 0, var = 0;
            for (float[] row : out) mean += row[c];
            mean /= frames;
            for (float[] row : out) var += (row[c] - mean) * (row[c] - mean);
            double sd = Math.sqrt(var / frames) + 1e-6;
            for (float[] row : out) row[c] = (float) ((row[c] - mean) / sd);
        }
        return out;
    }

    /** Average per-step distance after time warping. Smaller means more alike. */
    static double distance(float[][] a, float[][] b) {
        int n = a.length, m = b.length;
        if (n == 0 || m == 0 || n > m * 1.6 || m > n * 1.6) return Double.MAX_VALUE;
        double[] prev = new double[m + 1], cur = new double[m + 1];
        java.util.Arrays.fill(prev, 1e18);
        prev[0] = 0;
        for (int i = 1; i <= n; i++) {
            cur[0] = 1e18;
            for (int j = 1; j <= m; j++) {
                double d = 0;
                for (int c = 0; c < a[i - 1].length; c++) {
                    double x = a[i - 1][c] - b[j - 1][c];
                    d += x * x;
                }
                d = Math.sqrt(d);
                cur[j] = Math.min(prev[j - 1] + 2 * d, Math.min(prev[j] + d, cur[j - 1] + d));
            }
            double[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[m] / (n + m);
    }

    private static double mel(double hz) {
        return 2595 * Math.log10(1 + hz / 700);
    }

    private static void fft(double[] re, double[] im) {
        int n = re.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                double t = re[i]; re[i] = re[j]; re[j] = t;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = -2 * Math.PI / len;
            for (int i = 0; i < n; i += len) {
                for (int k = 0; k < len / 2; k++) {
                    double wr = Math.cos(ang * k), wi = Math.sin(ang * k);
                    int u = i + k, v = u + len / 2;
                    double xr = re[v] * wr - im[v] * wi, xi = re[v] * wi + im[v] * wr;
                    re[v] = re[u] - xr; im[v] = im[u] - xi;
                    re[u] += xr; im[u] += xi;
                }
            }
        }
    }
}
